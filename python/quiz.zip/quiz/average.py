no1 = float( input("enter the first number: "))

no2 = float( input("enter the second number: "))

no3 = float( input("enter the third number: "))

av = (no1 + no2 + no3) / 3

print ("the average of: " ,no1 ,no2 ,no3 ,"is: " ,av)