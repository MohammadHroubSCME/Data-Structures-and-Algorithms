v = float( input("enter radius: "))

area = v * v * 3.14159

print ("the area for the circle of radius", v, "is", area)