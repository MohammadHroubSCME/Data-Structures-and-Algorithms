no1 = float( input("enter the first number: "))
no2 = float( input("enter the second number: "))
no3 = float( input("enter the 3rd number: "))
no4 = float( input("enter the 4rd number: "))
no5 = float( input("enter the 5rd number: "))
no6 = float( input("enter the 6rd number: "))
no7 = float( input("enter the 7rd number: "))
no8 = float( input("enter the 8rd number: "))
no9 = float( input("enter the 9rd number: "))
no10 = float( input("enter the 10rd number: "))

av = (no1 + no2 + no3 + no4 + no5 + no6 + no7 + no8 + no9 + no10) / 10

print ("your average is: " ,av)