radius = 20

area = radius * radius * 3.14159

print ("the area for the circle of radius", radius, "is", area)